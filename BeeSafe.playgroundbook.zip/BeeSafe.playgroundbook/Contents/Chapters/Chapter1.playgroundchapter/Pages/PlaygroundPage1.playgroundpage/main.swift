//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport

let blair = Person()


//#-end-hidden-code
/*:
 # Blair's story
 
 * Note:
 Blair is a buzzing little bee that loves having fun with their friends and family.🐝💕🐝 But lately a lot of bees have been getting sick! 🦠 The queen said that bees can't play together for some time, to protect everyone around. Let's help Blair navigate this strange new world. 🌎
 
 Let's use the power of code to help Blair start their day!
 
 In Swift we use [functions](glossary://Function) to get something done.
 Let's write our first function: `goToWork()` to help our friend go to work.
 
 # Your turn:
 1. Call the function `goToWork()` on `blair`
 2. Tap on "Run My Code"
 
 If you get stuck check the Hints on the bottom right corner of the Live View ➡
 
 Write your code down here! ⬇
 */

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, goToWork())
blair.
//#-hidden-code
var text = "**Congratulations!** You just called a function! We're ready for the next step in our journey! Let's see what comes [next](@next)."
PlaygroundPage.current.assessmentStatus = .pass(message: text)
//#-end-hidden-code
