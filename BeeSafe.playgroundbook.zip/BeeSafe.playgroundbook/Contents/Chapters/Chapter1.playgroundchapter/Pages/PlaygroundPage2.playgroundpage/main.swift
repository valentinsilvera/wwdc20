//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport

let blair = Person()

//#-end-hidden-code
/*:
 # Keep your distance!
 
 * Note:
 Blair is not just a working bee, they're an **essential** working bee!🐝💼 That means that even though some bees can stay at home, Blair still needs to go to work to help others. 🤝 Now Blair needs to pay extra attention to stay at least 6 feet / 1.5 meters away from other bees! 📏
 
 Let's change a [boolean](glossary://Boolean) [variable](glossary://Variable) to see where the other bees are coming from.
 You can move Blair with your finger (they love flying around!); once the other workers are in the scene, try to keep your distance from them!
 
 # Your turn:
 1. Assign a **value** to the variable `showWorkers`
 2. Tap on "Run My Code"
 
 If you get stuck check the Hints on the bottom right corner of the Live View ➡
 
 Write your code down here! ⬇
 */

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, true, false)
var showWorkers = /*#-editable-code*/<#T##type here##Bool#>/*#-end-editable-code*/

//#-hidden-code

if showWorkers == true {
    do {
        blair.spawnNow()
    }
    catch {
        
    }
    PlaygroundPage.current.assessmentStatus = .pass(message: "Wow! Look at all those busy bees! Remember to keep your distance!✋ When you're ready we can go to the [**next page**](@next)!")
}


//#-end-hidden-code
