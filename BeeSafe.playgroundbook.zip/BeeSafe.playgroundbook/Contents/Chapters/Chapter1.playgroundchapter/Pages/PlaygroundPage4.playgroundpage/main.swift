//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport

let blair = Person()

func faceTimeCall(person: String) {
    if person == "grandma"{
        do {
            blair.callGrandma()
        }
        catch {
            
        }
        PlaygroundPage.current.assessmentStatus = .pass(message: "Surprise! Blair's grandma is the queen! She was so happy to get Blair's call. Thank you for helping them out so much, let's go to the [**last page**](@next)!")
    }
}


//#-end-hidden-code
/*:
 # Granny's birthday
 
 * Note:
 With all this work Blair almost forgot it's grandma Beatrice's birthday🎂! And even though this time Blair won't be able to go visit grandma, they have something in mind📱. Let's surprise grandma with a FaceTime call🎉!
 
 Let's finish this adventure through Swift by rehearsing all that we've learned so far, plus [strings](glossary://String)! Make a `faceTimeCall(person)` and give the [parameter](glossary://Parameter) `"grandma"`.
 
 # Your turn:
 1. Call the function `faceTimeCall(person)` and pass `"grandma"` as its parameter
 2. Tap on "Run My Code"
 
 If you get stuck check the Hints on the bottom right corner of the Live View ➡
 
 Write your code down here! ⬇
 */

//#-code-completion(identifier, show, faceTimeCall(person: String), "grandma")

/*#-editable-code*//*#-end-editable-code*/

//#-hidden-code
//#-end-hidden-code
