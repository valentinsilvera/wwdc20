//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport

let blair = Person()

func faceTimeCall(person: String) {
    if person == "grandma"{
        do {
            blair.callGrandma()
        }
        catch {
            
        }
        PlaygroundPage.current.assessmentStatus = .pass(message: "Surprise! Blair's grandma is the queen! She was so happy to get Blair's call. Thank you for helping them out so much, let's go to the [**last page**](@next)!")
    }
}


//#-end-hidden-code
/*:
 # Thank you!
 
 Thanks for helping Blair stay safe and make everyone stay safe at the same time too! This Playground Book is dedicated  to all the essential workers that have kept our society going forward. Doctors, nurses, shop employees, companies and their employees that, like Apple, have donated masks and equipment, and everyone else. You inspire us all!
 
 Just like Blair, I'm a social bee living in Berlin, Germany. I looove meeting friends to hang out, have fun and code together! So it's been tough to stay at home for these last few months. But it also helped me discover and come up with new ways to keep in touch and stay safe. Like this playground! I hope you had fun, learned with it, and maybe even got inspired to come up with something cool to share with people.
 
 And remember: stay healthy and Bee Safe!

 */
