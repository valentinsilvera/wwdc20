//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport

let blair = Person()

func washHandsFor(seconds: Double) {
    
    var seconds = seconds
    
    if seconds >= 20.0  {
        do {
            blair.washHands()
        }
        catch {
            
        }
        PlaygroundPage.current.assessmentStatus = .pass(message: "That virus stood no chance against that hand wash! 🧼 We can go to the [**next page**](@next)!")
    } else {
        do {
            blair.notEnoughTime()
        }
        catch {
            
        }
    }
}


//#-end-hidden-code
/*:
 # Let's get those hands clean!
 
 * Note:
 One of the best ways to stay healthy and protect ourselves is to be careful of what's on our hands. Blair just came back home so we need to clean our hands with soap and water, all 6 of them✋✋✋🧼🤚🤚🤚! The queen said we should spend at least **20 seconds** washing our hands⏱. Let's do it!
 
 Let's try changin the `seconds` [parameter](glossary://Parameter) of `washHandsFor(seconds)`. This function accepts [Doubles](glossary://Doubles), Floats or [integers](glossary://Integer)! so we can give it any number like 10 or 20.0.
 
 # Your turn:
 1. Write the appropriate parameter on `washHandsFor(seconds: Double`)
 2. Tap on "Run My Code"
 
 If you get stuck check the Hints on the bottom right corner of the Live View ➡
 
 Write your code down here! ⬇
 */

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, 10.5, 20.0, 45.02)

washHandsFor(seconds:/*#-editable-code*/<#T##number of seconds##Int#>/*#-end-editable-code*/)

//#-hidden-code
//#-end-hidden-code
