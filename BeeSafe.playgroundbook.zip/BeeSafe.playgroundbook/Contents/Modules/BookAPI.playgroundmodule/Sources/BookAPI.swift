//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Contains classes/structs/enums/functions which are part of a module that is
//  automatically imported into user-editable code.
//

import BookCore

// Implement any classes/structs/enums/functions in the BookAPI module which you
// want to be automatically imported and visible for users on playground pages
// and in user modules.
//
// This is controlled via the book-level `UserAutoImportedAuxiliaryModules`
// Manifest.plist key.

import Foundation
import UIKit
import PlaygroundSupport


public func showPassMessage(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public class Person: PlaygroundLiveViewMessageHandler {
    public init() {}
    
    public func goToWork() {
        sendValue(.string("work"))
    }
    
    public func washHands() {
        sendValue(.string("wash"))
    }
    
    public func notEnoughTime() {
        sendValue(.string("moreTime"))
    }
    
    public func spawnNow () {
        sendValue(.string("spawnWorkers"))
    }
    
    public func callGrandma() {
        sendValue(.string("call"))
    }
}
