//
//  Scene02.swift
//  BookCore
//
//  Created by Valentin Silvera on 06/05/2020.
//

import Foundation
import SpriteKit
import PlaygroundSupport

class Scene02: GameScene {
    
    let beeBack = SKSpriteNode(imageNamed: "beeBack1")
    let beeBackAnimation: SKAction
    let workerAnimation: SKAction
    var lastUpdateTime: TimeInterval = 0
    var dt: TimeInterval = 0
    let beeMovePointsPerSec: CGFloat = 300.0
    var velocity = CGPoint.zero
    var invincible = false
    static var spawning = false
    
    override init() {
        //animate the bee
        
        var textures:[SKTexture] = []
        for i in 1...3 {
            textures.append(SKTexture(imageNamed: "beeBack\(i)"))
        }
        textures.append(textures[1])
        beeBackAnimation = SKAction.animate(with: textures,
                                            timePerFrame: 0.05)
        // animate the workers
        
        var workerTextures:[SKTexture] = []
        for i in 1...3 {
            workerTextures.append(SKTexture(imageNamed: "worker\(i)"))
        }
        workerTextures.append(workerTextures[1])
        workerAnimation = SKAction.animate(with: workerTextures,
                                            timePerFrame: 0.05)
        
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
        //set background and music
        
        super.playBackgroundMusic()
        createBackground()
        
        // load bee
        
        beeBack.position = CGPoint(x: size.width/2, y: size.height/3)
        beeBack.setScale(0.2)
        addChild(beeBack)
        beeBack.run(SKAction.repeatForever(beeBackAnimation))
        
        // spawn workers
        
        run(SKAction.repeatForever(
            SKAction.sequence([SKAction.run() { [weak self] in
                self?.spawnWorker()
                },
                               SKAction.wait(forDuration: 2.0)])))
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        if lastUpdateTime > 0 {
            dt = currentTime - lastUpdateTime
        } else {
            dt = 0
        }
        lastUpdateTime = currentTime
        
        move(sprite: beeBack, velocity: velocity)
        boundsCheckBee()
        moveBackground()
    }
    
    // create and move a looping background
    
    func createBackground() {
        for i in 0...3 {
            let bg = SKSpriteNode(imageNamed: "grassBG")
            bg.name = "background"
            bg.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            bg.setScale(0.5)
            bg.position = CGPoint(x: size.width/2, y: CGFloat(i) * bg.size.height)
            
            self.addChild(bg)
        }
    }
    
    func moveBackground() {
        self.enumerateChildNodes(withName: "background", using: ({
            (node, error) in
            node.position.y -= 3
            if node.position.y < -((self.scene?.size.height)!) {
                node.position.y += (self.scene?.size.height)! * 3
            }
        }))
    }
    
    // make sure the bee doesn't disappear from the frame
    
    override func didEvaluateActions() {
        checkCollisions()
    }
    
    func checkCollisions() {
        if invincible {
            return
        }
        
        var hitWorkers: [SKSpriteNode] = []
        enumerateChildNodes(withName: "worker") { node, _ in
            let worker = node as! SKSpriteNode
            if node.frame.insetBy(dx: 20, dy: 20).intersects(
                self.beeBack.frame) {
                hitWorkers.append(worker)
            }
        }
        for worker in hitWorkers {
            beeHit(worker: worker)
        }
    }
    
    // evaluate if the bee hits a worker
    
    func beeHit(worker: SKSpriteNode) {
        invincible = true
        let blinkTimes = 10.0
        let duration = 3.0
        let blinkAction = SKAction.customAction(withDuration: duration) { node, elapsedTime in
            let slice = duration / blinkTimes
            let remainder = Double(elapsedTime).truncatingRemainder(
                dividingBy: slice)
            node.isHidden = remainder > slice / 2
        }
        let setHidden = SKAction.run() { [weak self] in
            self?.beeBack.isHidden = false
            self?.invincible = false
        }
        beeBack.run(SKAction.sequence([blinkAction, setHidden]))
    }
    
    func move(sprite: SKSpriteNode, velocity: CGPoint) {
        let amountToMove = CGPoint(x: velocity.x * CGFloat(dt),
                                   y: velocity.y * CGFloat(dt))
        sprite.position = CGPoint(
            x: sprite.position.x + amountToMove.x,
            y: sprite.position.y + amountToMove.y)
    }
    
    func moveBeeTowards(location: CGPoint) {
        let offset = CGPoint(x: location.x - beeBack.position.x,
                             y: location.y - beeBack.position.y)
        let length = sqrt(
            Double(offset.x * offset.x + offset.y * offset.y))
        let direction = CGPoint(x: offset.x / CGFloat(length),
                                y: offset.y / CGFloat(length))
        velocity = CGPoint(x: direction.x * beeMovePointsPerSec,
                           y: direction.y * beeMovePointsPerSec)
    }
    
    // evaluate touches
    
    func sceneTouched(touchLocation:CGPoint) {
        moveBeeTowards(location: touchLocation)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>,
                               with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        let touchLocation = touch.location(in: self)
        sceneTouched(touchLocation: touchLocation)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>,
                               with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        let touchLocation = touch.location(in: self)
        sceneTouched(touchLocation: touchLocation)
    }
    
    func boundsCheckBee() {
        let bottomLeft = CGPoint(x: size.width/4, y: 0)
        let topRight = CGPoint(x: size.width/1.3, y: size.height)
        
        if beeBack.position.x <= bottomLeft.x {
            beeBack.position.x = bottomLeft.x
            velocity.x = -velocity.x
        }
        if beeBack.position.x >= topRight.x {
            beeBack.position.x = topRight.x
            velocity.x = -velocity.x
        }
        if beeBack.position.y <= bottomLeft.y {
            beeBack.position.y = bottomLeft.y
            velocity.y = -velocity.y
        }
        if beeBack.position.y >= topRight.y {
            beeBack.position.y = topRight.y
            velocity.y = -velocity.y
        }
    }
    
    func spawnWorker() {
        let worker = SKSpriteNode(imageNamed: "worker1")
        worker.name = "worker"
        worker.position = CGPoint(
            x: CGFloat.random(in: size.width/4 ... size.width/1.3),
            y: self.scene?.size.height ?? 650)
        worker.zPosition = 50
        worker.setScale(0.2)
        if Scene02.spawning == true {
            addChild(worker)
        }
        worker.run(SKAction.repeatForever(workerAnimation))
        
        let actionMove =
            SKAction.moveBy(x: 0, y: -(size.height + worker.size.height), duration: 3.0)
        let actionRemove = SKAction.removeFromParent()
        worker.run(SKAction.sequence([actionMove, actionRemove]))
    }
    
}
