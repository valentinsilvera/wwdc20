//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import PlaygroundSupport
import SpriteKit
import SceneKit
import GameKit

public func instantiateViewController(for page: String) -> PlaygroundLiveViewable {
    
    switch page {
    case "p1":
        return  GameViewController(scene: Scene01())
    case "p2":
        return  GameViewController(scene: Scene02())
    case "p3":
        return  GameViewController(scene: Scene03())
    case "p4":
        return  GameViewController(scene: Scene04())
    default:
        return GameViewController(scene: Scene05())
    }
}

public protocol PlaygroundValueConvertible {
    func asPlaygroundValue() -> PlaygroundValue
}

public func sendValue(_ value: PlaygroundValueConvertible) {
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(value.asPlaygroundValue())
}

public func sendValue(_ value: PlaygroundValue) {
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(value)
}
