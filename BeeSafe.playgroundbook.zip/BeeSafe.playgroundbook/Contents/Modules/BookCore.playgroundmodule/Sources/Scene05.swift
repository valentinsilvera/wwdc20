//
//  Scene05.swift
//  BookCore
//
//  Created by Valentin Silvera on 08/05/2020.
//

import Foundation
import SpriteKit
import SceneKit
import GameKit

class Scene05: GameScene {
    
    let bee = SKSpriteNode(imageNamed: "beeFront1")
    let beeFrontAnimation: SKAction
    let sky = SKSpriteNode(imageNamed: "sky1")
    let skyAnimation: SKAction
    var lastUpdateTime: TimeInterval = 0
    var dt: TimeInterval = 0
    
    override init() {
        
        //animate the bee
        
        var textures:[SKTexture] = []
        for i in 1...3 {
            textures.append(SKTexture(imageNamed: "beeFront\(i)"))
        }
        textures.append(textures[1])
        beeFrontAnimation = SKAction.animate(with: textures,
                                             timePerFrame: 0.1)
        // animate the background
        
        var texturesSky:[SKTexture] = []
        texturesSky.append(SKTexture(imageNamed: "sky1"))
        texturesSky.append(SKTexture(imageNamed: "sky2"))
        skyAnimation = SKAction.animate(with: texturesSky,
                                        timePerFrame: 0.3)
        
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
        
        //set background and music
        
        super.playBackgroundMusic()
        
        sky.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(sky)
        sky.run(SKAction.repeatForever(skyAnimation))
        createBackground()
        
        // load bee
        
        bee.position = CGPoint(x: size.width/2, y: size.height/3)
        bee.setScale(0.5)
        addChild(bee)
        bee.run(SKAction.repeatForever(beeFrontAnimation))
        
        // move bee up and down smoothly
        
        let moveUp = SKAction.moveBy(x: 0, y: 50, duration: 1)
        moveUp.timingMode = .easeInEaseOut
        let sequence = SKAction.sequence([moveUp, moveUp.reversed()])
        bee.run(SKAction.repeatForever(sequence), withKey:  "moving")
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        if lastUpdateTime > 0 {
            dt = currentTime - lastUpdateTime
        } else {
            dt = 0
        }
        lastUpdateTime = currentTime
        
        moveBackground()
    }
    
    // move clouds
    
    func createBackground() {
        for i in 0...3 {
            let bg = SKSpriteNode(imageNamed: "clouds")
            bg.name = "background"
            bg.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            bg.setScale(0.5)
            bg.position = CGPoint(x: CGFloat(i) * bg.size.height, y: size.height/2)
            bg.alpha = 0.5
            
            self.addChild(bg)
        }
    }
    
    func moveBackground() {
        self.enumerateChildNodes(withName: "background", using: ({
            (node, error) in
            node.position.x -= 1
            if node.position.x < -((self.scene?.size.width)!) {
                node.position.x += (self.scene?.size.width)! * 3
            }
        }))
    }
}

