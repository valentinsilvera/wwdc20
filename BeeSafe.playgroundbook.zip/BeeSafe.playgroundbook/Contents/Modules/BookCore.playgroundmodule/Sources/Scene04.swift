//
//  Scene04.swift
//  BookCore
//
//  Created by Valentin Silvera on 07/05/2020.
//

import Foundation
import SpriteKit
import SceneKit
import GameKit

class Scene04: GameScene {
    
    let callIdle = SKSpriteNode(imageNamed: "callIdle")
    let call = SKSpriteNode(imageNamed: "call1")
    let callAnimation : SKAction
    let gradient01 = SKSpriteNode(imageNamed: "sky1")
    static var calling = false
    
    override init() {
        
        //animate the call
        
        var textures:[SKTexture] = []
        // main char talk
        for _ in 1...3{
            textures.append(SKTexture(imageNamed: "call1"))
            textures.append(SKTexture(imageNamed: "call2"))
        }
        
        // aniamte talking scene
        
        for _ in 1...3 {
            textures.append(SKTexture(imageNamed: "call3"))
            textures.append(SKTexture(imageNamed: "call4"))
        }
        callAnimation = SKAction.animate(with: textures,
                                         timePerFrame: 0.3)
        
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
        
        //set background and music
        
        super.playBackgroundMusic()
        
        gradient01.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(gradient01)
        
        // load phone
        
        callIdle.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        callIdle.position = CGPoint(x: size.width/2, y: size.height/2)
        callIdle.setScale(0.9)
        addChild(callIdle)
        
        run(SKAction.repeatForever(
            SKAction.sequence([SKAction.run() { [weak self] in
                self?.callNow()
                },
                               SKAction.wait(forDuration: 3)])))
    }
    
    func callNow() {
        let call = SKSpriteNode(imageNamed: "call1")
        call.name = "call"
        call.position = CGPoint(x: size.width/2, y: size.height/2)
        call.zPosition = 50
        call.setScale(0.9)
        if Scene04.calling == true {
            addChild(call)
        }
        call.run(SKAction.repeatForever(callAnimation))
    }
    
}
