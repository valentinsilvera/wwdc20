//
//  Scene03.swift
//  BookCore
//
//  Created by Valentin Silvera on 07/05/2020.
//

import Foundation
import SpriteKit
import SceneKit
import GameKit

class Scene03: GameScene {
    
    static let handsL = SKSpriteNode(imageNamed: "handsL")
    static let handsR = SKSpriteNode(imageNamed: "handsR")
    static let speechBubbleWash = SKSpriteNode(imageNamed: "speech1")
    let sink = SKSpriteNode(imageNamed: "sink1")
    let sinkAnimation: SKAction
    
    override init() {
        
        // animate water in the sink
        
        var textures:[SKTexture] = []
        for i in 1...4 {
            textures.append(SKTexture(imageNamed: "sink\(i)"))
        }
        textures.append(textures[2])
        textures.append(textures[1])
        sinkAnimation = SKAction.animate(with: textures,
                                           timePerFrame: 0.3)
        
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
        //set background and music
        
        super.playBackgroundMusic()
        
        sink.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(sink)
        sink.run(SKAction.repeatForever(sinkAnimation))
        
        // load hands
        
        Scene03.handsL.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        Scene03.handsL.position = CGPoint(x: size.width/2.4, y: size.height/2.7)
        Scene03.handsL.setScale(0.45)
        addChild(Scene03.handsL)
        
        Scene03.handsR.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        Scene03.handsR.position = CGPoint(x: size.width/1.6, y: size.height/2.7)
        Scene03.handsR.setScale(0.45)
        addChild(Scene03.handsR)
        
    }
    
}
