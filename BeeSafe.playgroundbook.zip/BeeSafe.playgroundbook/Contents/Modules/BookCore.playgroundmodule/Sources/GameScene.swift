//
//  GameScene.swift
//  BookCore
//
//  Created by Valentin Silvera on 06/05/2020.
//

import Foundation
import SpriteKit
import PlaygroundSupport

class GameScene:SKScene {
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init() {
        
        super.init(size:  UIScreen.main.bounds.size)
        self.backgroundColor = UIColor.white
    }
    
    override func didMove(to view: SKView) {
        
    }
    
    // flies off the screen to the top
    
    func flyAway() {
        let fly = SKAction.moveBy(x: 0, y: 800, duration: 2)
        fly.timingMode = .easeIn
        Scene01.beeFront.run(fly)
        
    }
    
    //either plays the washing hands animation or presents a label that it needs more time
    
    func washHands(){
        let moveDiagonallyL = SKAction.moveBy(x: 60, y: 30, duration: 0.6)
        moveDiagonallyL.timingMode = .easeInEaseOut
        let sequenceL = SKAction.sequence([moveDiagonallyL, moveDiagonallyL.reversed()])
        Scene03.handsL.run(SKAction.repeatForever(sequenceL), withKey:  "moveHandL")
        let moveDiagonallyR = SKAction.moveBy(x: -60, y: 30, duration: 0.6)
        moveDiagonallyR.timingMode = .easeInEaseOut
        let sequenceR = SKAction.sequence([moveDiagonallyR, moveDiagonallyR.reversed()])
        Scene03.handsR.run(SKAction.repeatForever(sequenceR), withKey:  "moveHandL")
        addEmitter(pos: "top")
        addEmitter(pos: "middle")
        addEmitter(pos: "bottom")
        Scene03.speechBubbleWash.removeFromParent()
    }
    
    func washMoreTime() {
        Scene03.speechBubbleWash.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        Scene03.speechBubbleWash.position = CGPoint(x: size.width/2, y: size.height/2)
        Scene03.speechBubbleWash.setScale(0.25)
        addChild(Scene03.speechBubbleWash)
        return
    }
    
    //creates bubbles emitter
    
    func addEmitter(pos:String) {
        let emitter = SKEmitterNode(fileNamed: "Soap.sks")!
        let pos = pos
        switch pos {
        case "top":
            emitter.position = CGPoint(x: size.width/2, y: size.height/1.5)
        case "bottom":
            emitter.position = CGPoint(x: size.width/2, y: size.height/4)
        default:
            emitter.position = CGPoint(x: size.width/2, y: size.height/2.3)
        }
        addChild(emitter)
    }
    
    //adds or removes workers
    
    func spawnWorkers() {
        Scene02.spawning = true
    }
    
    // animates facetime call
    
    func callGrandma() {
        Scene04.calling = true
    }
    
    // play background music, called from individual scenes
    
    func playBackgroundMusic() {
        let backgroundMusic = SKAudioNode(fileNamed: "musicBG.mp3")
        backgroundMusic.autoplayLooped = true
        self.addChild(backgroundMusic)
    }
    
    
}
