//
//  GameViewController.swift
//  BookCore
//
//  Created by Valentin Silvera on 08/05/2020.
//

import Foundation
import UIKit
import SpriteKit
import GameKit
import PlaygroundSupport

class GameViewController: UIViewController, PlaygroundLiveViewMessageHandler {
    
    var skView: SKView!
    var scene: GameScene!
    
    init(scene: GameScene) {
        super.init(nibName: nil, bundle: nil)
        self.scene =  scene
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        super.loadView()
        skView = SKView.init(frame: self.view.frame)
        self.view = skView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // debug options
//        skView.showsFPS = true
//        skView.showsNodeCount = true
        skView.ignoresSiblingOrder = false
        scene.scaleMode = .aspectFill
        skView.presentScene(scene)
    }
    
    public func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running main.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        
        switch message {
        case .string(let str):
            switch str {
            case "work":
                scene.flyAway()
            case "wash":
                scene.washHands()
            case "moreTime":
                scene.washMoreTime()
            case "spawnWorkers":
                scene.spawnWorkers()
            case "call":
                scene.callGrandma()
            default:
                scene.flyAway()
            }
            
        default:
            return
        }
    }
    
}
