//
//  Scene01.swift
//  BookCore
//
//  Created by Valentin Silvera on 08/05/2020.
//

import Foundation
import SpriteKit
import SceneKit
import GameKit

class Scene01: GameScene {
    
    static let beeFront = SKSpriteNode(imageNamed: "beeFront1")
    let beeFrontAnimation: SKAction
    let background01 = SKSpriteNode(imageNamed: "hiveBG")
    let gradient01 = SKSpriteNode(imageNamed: "gradient1")
    
    
    override init() {
        //animate the bee
        
        var textures:[SKTexture] = []
        for i in 1...3 {
            textures.append(SKTexture(imageNamed: "beeFront\(i)"))
        }
        textures.append(textures[1])
        beeFrontAnimation = SKAction.animate(with: textures,
                                             timePerFrame: 0.1)
        
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
        
        //set background and music
        
        super.playBackgroundMusic()
        
        gradient01.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(gradient01)
        background01.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(background01)
        
        // load bee
        
        Scene01.beeFront.position = CGPoint(x: size.width/2, y: size.height/3)
        Scene01.beeFront.setScale(0.5)
        addChild(Scene01.beeFront)
        Scene01.beeFront.run(SKAction.repeatForever(beeFrontAnimation))
        
        // move bee up and down smoothly
        let moveUp = SKAction.moveBy(x: 0, y: 50, duration: 1)
        moveUp.timingMode = .easeInEaseOut
        let sequence = SKAction.sequence([moveUp, moveUp.reversed()])
        Scene01.beeFront.run(SKAction.repeatForever(sequence), withKey:  "moving")
        
    }
    
    
}
